# University

A collection of academic subjects, each a self-contained course taken
during a specific period. Every subject lives in its own directory
named `<CODE>-<PERIOD>` (for example `MGDSC-2026.2`). This README is the
first contract this repository has ever had.

## Layout

```text
university/
├── README.md                # first contract, documents invariants only
├── .gitignore               # standard excludes (venv, build outputs)
├── docker-compose.yml       # shared services used across subjects
├── attachments/
├── materials/               # academic-scope materials shared by all subjects
│   └── templates/           # academic document templates, used by handouts
├── <CODE>-<PERIOD>/         # one directory per subject+period
│   ├── meta.md              # bookplate, written once, never updated
│   ├── materials/           # professor-provided handouts and references
│   ├── topics/              # own study by topic (was course/)
│   ├── lab/                 # sketchpad: free-form projects, no required layout
│   └── personal/            # own practice, NNN_<slug>.<ext>
└── ...
```

No sufixos decorativos, sem pastas por linguagem ou data. Cada matéria tem
um `meta.md` livro-placa: escrito uma única vez, nunca mais atualizado.
Progresso é derivado da estrutura: o diretório de tópico mais alto com
conteúdo é o progresso.

## Subject placement

A subject directory `<CODE>-<PERIOD>` groups everything that belongs to one
specific course offering:

- `meta.md` describes the subject once (overview, professor, syllabus,
  topics, links) and is **never updated again**.
- `materials/` holds handouts from the professor. These are **not** copies of
  books — the contract of the whole workspace says: a book is studied in
  `studies/`; university references it, never duplicates it.
- `topics/` holds the student's own study of each theme: dated SQL scripts
  in chronological order, normalisation theory, conceptual diagrams, the
  project deliverable.
- `lab/` is a sketchpad. Create a folder or a file and start coding. There
  is **no required layout**, no naming pattern, no meta. Structure lives
  everywhere else; the lab is where structure goes to be tested.
- `personal/` holds own practice exercises, zero-padded and sequenced
  (`001_fundamentos_condicoes.py`, `002_while_acumuladores.py`, ...).

## Headers

Every Markdown note carries a frontmatter header; every code file carries
the comment block the header snippet generates. The Markdown header format
is the standard one used across `studies/` too, so the vocabulary is shared:

```yaml
---
title: <title>
tags:
    -
description:
authors:
source: <source>
location: <location>
external_urls:
related:
lang: en-US | pt-BR
date: <ISO date>
id: <id>
---
```

- `title` — the note title (matches the filename stem).
- `tags` — empty list by default; add `- <tag>` as needed.
- `description` — short description of the note content.
- `authors` — note authors (if different from subject professors).
- `source` — source book/course identifier.
- `location` — where in the subject the note belongs.
- `aliases` — empty list by default; add `- <alias>` as needed.
- `lang` — language code of the note content (`en-US` or `pt-BR`).
- `date` — ISO datetime when the note was created (or the date you’re recording).
- `id` — note identifier (UUID or descriptive string); leave empty `id: ` if unknown.

The fields `file_name`, `created_at` and `modified_at` are **removed** from this format.
Use `date` for creation and keep the note body’s edit history if needed.

When a file is renamed or moved, the `title` and `source`/`location` fields
should be updated to match the new filename and path.

## Placement rule (studies ↔ university)

A book or source is **studied** in `studies/`; university may **reference**
it, but never **copy** it. If the same edition of a book already exists in
studies, it is removed from university during migration. The goal is that
knowledge assets live in one place only; the other repo merely points to
them.

## Shared services

`university/docker-compose.yml` defines services shared across all subjects
(e.g. a PostgreSQL instance used in the SQL sessions). Its purpose is
documented there; each subject may reference the connection details in its
own `lab/` or `topics/` but the compose file lives at the repository root.

## Private Material

Directories beginning with `_` are private and are intentionally excluded
from version control. They allow personal or unpublished material to
coexist with the public portion of the repository without being committed
to Git.

## File naming conventions

Three families, one per location inside a subject:

### `topics/` — dated study artifacts

- **SQL scripts** (`topics/sql/`): `YYYY-MM-DD_<seq>_<slug>.sql`
  - `YYYY-MM-DD` is the ISO-created date (recovered from `git log`).
  - `<seq>` is a 2-digit sequential number within the same-day batch.
  - `<slug>` is `setup`, `tabelas`, `create_tables`, `inserts`, `filtros`, etc.
  - Example: `2026-10-06_00_setup.sql`, `2026-10-06_16_users.sql`.

- **Other study files** (normalisation, MER-DER, projeto): free-form filenames
  - No fixed pattern; just keep them in the appropriate subdirectory.
  - Notes use the universal `S<m>[_<n>[_<p>]]_<T><NNN>_<slug>.<ext>` pattern
    if they are also tracked in `studies/`; otherwise any descriptive name.

### `personal/` — own practice exercises

- `NNN_<slug>.<ext>` — zero-padded sequence, gaps allowed.
- Example: `001_fundamentos_condicoes.py`, `002_while_acumuladores.py`,
  `003_for_range.py`, `004_funcoes.py`, `008_dicts.py`, `009_dict_contador.py`.

### `lab/` — sketchpad, no required layout

- No naming pattern, no meta, no required structure.
- Create a folder or a file and start coding.
- Structure lives everywhere else; the lab is where structure goes to be tested.

## History

This is the first README this repository has ever had. It documents the
contract that makes the other reorganisations possible.
