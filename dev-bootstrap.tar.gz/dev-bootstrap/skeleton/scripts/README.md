# Scripts

Standalone tools authored here. One file per tool, self-contained: its
own configuration, its own state, no shared code between tools. A tool
may be symlinked onto `$PATH` but is never consumed in place by other
tools.

- `development/spr` — CLI for scaffolding Spring Boot projects via
  start.spring.io.
- `skills/` — packaged skill files (`.skill`).

This README is the source of truth for what lives here. When a tool is
added or removed, change this list in the same change.
extra
