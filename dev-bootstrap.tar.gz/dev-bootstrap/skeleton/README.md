# dev

The development workspace. Four domains, one rule each. This README is
the source of truth for the layout; a domain's own README refines it
(arcanum's is its full contract).

## Layout

```text
dev/
├── arcanum/      knowledge: scripts, snippets, docs, bugs, decisions, ideas
├── repos/        source code, one subfolder per domain
├── resources/    files that get copied into projects
├── scripts/      standalone tools and skills
└── work/         career material
```

## Domains

- **arcanum/** — everything worth writing down that is not code. Flat
  vault, conventions over classification. Its README is the contract.
- **repos/** — every line of code. Subfolders by ownership, never by
  language or date: `personal/` (own projects with remotes), `lab/`
  (experiments, one git repository for all of them), `studies/`,
  `university/`, `work/` (professional projects). A project lives in
  exactly one.
- **resources/** — licenses, templates and configuration that get copied
  into projects. Source, never destination. Its README is the contract.
- **scripts/** — tools that get run, not copied. One file per tool, each
  self-contained (`development/spr`, `skills/`).
- **work/** — documents that get sent to someone: `cv/`, `applications/`,
  `certificates/`, `documents/`.

## Placement

One question decides where a file goes: what happens to it?

- It is written and run → `repos/` (a project) or `scripts/` (a tool).
- It is copied somewhere else → `resources/`.
- It is read to remember → `arcanum/`.
- It is sent to someone → `work/`.

No `misc/`, no `archive/`, no `old/`. What is no longer needed is
deleted. If a rule changes, change it in this README first, then in the
implementations.
