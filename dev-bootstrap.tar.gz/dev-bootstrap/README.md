# dev-bootstrap

Fresh-machine fallback for the `~/dev` workspace (arcanum excluded).

```bash
./bootstrap.sh apply --dry-run   # preview
./bootstrap.sh apply             # create dirs, seed READMEs, git init repos/lab
./bootstrap.sh check             # verify layout
./bootstrap.sh sync              # pull edited READMEs from ~/dev into skeleton/
```

`skeleton/` mirrors `~/dev` and holds the real files. To ship a new file
(template, license, config), put it in `skeleton/` at its final path.
